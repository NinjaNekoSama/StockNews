import requests
from twilio.rest import Client
import os

STOCK = "TSLA"
COMPANY_NAME = "Tesla Inc"
api_key = os.environ.get("API_KEY")
function = "TIME_SERIES_DAILY_ADJUSTED"
SORT = "popularity"
NEWS_API_KEY = os.environ.get("NEWS_API_KEY")
LANGUAGE = "en"
account_sid = os.environ.get("SID")
auth_token = os.environ.get("AUTH_TOKEN")

parameters = {
    "function": function,
    "symbol": STOCK,
    "outputsize": "compact",
    "apikey": api_key,
}

## STEP 1: Use https://www.alphavantage.co
# When STOCK price increase/decreases by 5% between yesterday and the day before yesterday then print("Get News").

response = requests.get("https://www.alphavantage.co/query", params=parameters)
response.raise_for_status()
stock_data = response.json()['Time Series (Daily)']
close_values = []
for (key, value) in stock_data.items():
    close_values.append(stock_data[key]['4. close'])
diff = float(close_values[0]) - float(close_values[1])
percent_diff = round((diff / float(close_values[1])) * 100, 2)

if percent_diff > 0:
    final_change = "🔺" + str(abs(percent_diff)) + "%"
elif percent_diff < 0:
    final_change = "🔻" + str(abs(percent_diff)) + "%"
else:
    final_change = str(abs(percent_diff)) + "%"

print(final_change)

NEWS_PARAMETERS = {

    "q": COMPANY_NAME,
    "from": close_values[0],
    "sortBy": SORT,
    "language": LANGUAGE,
    "apiKey": NEWS_API_KEY

}
## STEP 2: Use https://newsapi.org
# Instead of printing ("Get News"), actually get the first 3 news pieces for the COMPANY_NAME.
if abs(percent_diff) >= 1:
    news_response = requests.get("https://newsapi.org/v2/everything", params=NEWS_PARAMETERS)
    news_response.raise_for_status()
    news_data = news_response.json()['articles']
    # print(news_data)
    for key in news_data:
        if "Tesla" in key['title']:
            my_news = f"TSLA:{final_change}\nHeadline:{key['title']}\nBrief:{key['content'][0:150]}"
            ## STEP 3: Use https://www.twilio.com
            # Send a seperate message with the percentage change and each article's title and description to your phone number.
            client = Client(account_sid, auth_token)
            message = client.messages \
                .create(
                body=my_news,
                from_=os.environ.get("other_no"),
                to=os.environ.get("phone_no")
            )
            print(message.status)
            # print(my_news)
            break

# print(percent_diff)
# print(close_values)

# percent_change = int(stock_data[0:1]["close"])-int(stock_data[0:1]['close'])
# print(stock_data)


# Optional: Format the SMS message like this:
"""
TSLA: 🔺2%
Headline: Were Hedge Funds Right About Piling Into Tesla Inc. (TSLA)?. 
Brief: We at Insider Monkey have gone over 821 13F filings that hedge funds and prominent investors are required to file by the SEC The 13F filings show the funds' and investors' portfolio positions as of March 31st, near the height of the coronavirus market crash.
or
"TSLA: 🔻5%
Headline: Were Hedge Funds Right About Piling Into Tesla Inc. (TSLA)?. 
Brief: We at Insider Monkey have gone over 821 13F filings that hedge funds and prominent investors are required to file by the SEC The 13F filings show the funds' and investors' portfolio positions as of March 31st, near the height of the coronavirus market crash.
"""
